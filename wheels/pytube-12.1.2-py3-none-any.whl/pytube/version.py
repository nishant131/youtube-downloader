__version__ = "12.1.2"

if __name__ == "__main__":
    print(__version__)
